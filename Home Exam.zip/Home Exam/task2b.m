clear
clc

H1 = [3, -4, 0;
      -4, 3, 0;
      1,  0, 1];
  
H2 = [3, -4, 0;
      -4, 3, 0;
      0,  0, 1];
  
x1 = [0,1,1]';
x2 = [-5,0,1]';

H1x1 = pflat(H1*x1);
H1x2 = pflat(H1*x2);
H2x1 = pflat(H2*x1);
H2x2 = pflat(H2*x2);

