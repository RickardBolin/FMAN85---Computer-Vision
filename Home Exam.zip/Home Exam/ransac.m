function best_idx = ransac(X, x1, x2, num_correspondences, iter)
    n_points = size(X,2);
    best_error = 0; 
    best_idx = 0;
    for i=1:iter
        idx = randperm(n_points,num_correspondences); 
        plane = null (X (: , idx )');
        plane = plane ./ norm ( plane (1:3));
        distance = abs (plane' * X);
        inlierIdx = find(abs(distance)<=threshDist);
        inlierNum = length(inlierIdx);   
        if inlierNum>=round(inlierRatio*n_points) && inlierNum>mostInliers
             mostInliers = inlierNum;
             bestInlierIdx = inlierIdx
             bestPlane = plane;
        end
    end
end